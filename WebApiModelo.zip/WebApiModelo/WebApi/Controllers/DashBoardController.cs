﻿using Domain.InterfacesDashboard;
using Entities.ModelsFiltros;
using Entities.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;



namespace WebApi.Controllers
{
    public class DashBoardController : Controller
    {
        public readonly IDashboard _IDashboard;

        public DashBoardController(IDashboard IDashboard)
        {
            _IDashboard = IDashboard;
        }


        [HttpPost]
        [Route("ObterTipoSegmentoNPS")]
        public async Task<JsonResult> ObterTipoSegmentoNPS(FiltroPadrao filtroPadrao)
        {
            return Json(await _IDashboard.ObterTipoSegmentoNPS(filtroPadrao));
        }


        [HttpGet]
        [Route("ObterComboAtributos")]
        public async Task<IActionResult> ObterComboAtributos()
        {
            return Json(await _IDashboard.ObterComboAtributos());
        }


    }
}
