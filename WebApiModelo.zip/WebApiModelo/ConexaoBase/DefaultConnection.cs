﻿using System;

namespace ConexaoBase
{
    public static class DefaultConnection
    {
        public static string GetStringConectionConfig(string nomeBanco, bool isProd)
        {
            SisConn.clsAcessoBanco clsAcessoBanco = new SisConn.clsAcessoBanco();
            var strCon = clsAcessoBanco.RetornaConexaoSSRS(nomeBanco, isProd);
            return strCon;
        }
    }
}
