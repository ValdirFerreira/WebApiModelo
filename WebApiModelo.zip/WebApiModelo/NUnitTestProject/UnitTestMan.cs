﻿
using Infrastructure.Repositories;

using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Threading.Tasks;
namespace NUnitTestProject
{

    [TestClass]
    public class UnitTestMan
    {

        [TestMethod]
        public async Task ObterComboAtributos()
        {
            try
            {
                var _IDashboard = new RepositoryDashboard();

                var retorno = await _IDashboard.ObterComboAtributos();

                Assert.IsTrue(retorno.Count > 0);
            }
            catch (Exception)
            {

                Assert.Fail();
            }



        }
    }
}
