﻿using Domain.InterfacesDashboard;
using Domain.ServiceTrataFiltros;
using Domain.TrataDadosDashboard;
using Entities.ModelsFiltros;
using Entities.NPSSegmentoModel;
using Infrastructure.Configuration;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Infrastructure.Repositories
{
    public class RepositoryDashboard : RepositoryGenerics, IDashboard
    {

        private readonly DbContextOptions<ContextBase> _optionsbuilder;

        public RepositoryDashboard()
        {
            _optionsbuilder = new DbContextOptions<ContextBase>();
        }

        public async Task<List<NPSSegmentoModel>> ObterTipoSegmentoNPS(FiltroPadrao filtroPadrao)
        {
            using (var banco = new ContextBase(_optionsbuilder))
            {
                var param = TratadadosFiltroPadrao.TrataDadosFiltrosDrillDowNPS(filtroPadrao);

                var baseSegmentoModel = await banco.Set<BaseSegmentoModel>().FromSqlRaw("sp_DrillDown_Linha1Bloco1_NPS ", param).ToListAsync();

                return TrataDadosGraficoDrillDownNPS.TrataDados(baseSegmentoModel);

            }
        }


        public async Task<List<ComboAtributosModel>> ObterComboAtributos()
        {
            using (var banco = new ContextBase(_optionsbuilder))
            {
                var comboAtributos = await banco.Set<ComboAtributosModel>().FromSqlRaw("exec sp_ComboAtributos ").AsNoTracking().ToListAsync();
                return comboAtributos.OrderBy(a => a.DescItem).ToList();

            }
        }

    }
}
