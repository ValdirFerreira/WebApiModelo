﻿using Dapper;
using Entities.ModelsFiltros;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;


namespace Domain.ServiceTrataFiltros
{
    public static class TratadadosFiltroPadrao
    {

        public static DynamicParameters TrataDadosFiltrosDrillDowNPS(FiltroPadrao filtroPadrao)
        {

            var listaVisao = filtroPadrao.ParamVisaoMPE != null ? string.Join(";", filtroPadrao.ParamVisaoMPE) : "";
            var listaistaSegmento = filtroPadrao.ParamSegmento != null ? string.Join(";", filtroPadrao.ParamSegmento) : "";
            var listaEncarteiramento = filtroPadrao.ParamEncarteiramento != null ? string.Join(";", filtroPadrao.ParamEncarteiramento) : "";
            var listaSuperintendencia = filtroPadrao.ParamSuperintendencia != null ? string.Join(";", filtroPadrao.ParamSuperintendencia) : "";
            var listaRegiao = filtroPadrao.ParamRegiao != null ? string.Join(";", filtroPadrao.ParamRegiao) : "";
            var listaEstado = filtroPadrao.ParamEstado != null ? string.Join(";", filtroPadrao.ParamEstado) : "";

            var tipoPeriodo = filtroPadrao.ParamTipoPeriodo != 0 ? filtroPadrao.ParamTipoPeriodo : 2;
            var periodo = filtroPadrao.ParamPeriodo != 0 ? filtroPadrao.ParamPeriodo : 16;

            var codTabulacaoItem = filtroPadrao.ParamCodTabulacaoItem != 0 ? filtroPadrao.ParamCodTabulacaoItem : 1;

            var parametros = new DynamicParameters();
            parametros.Add("@ParamCodTipoPeriodo", tipoPeriodo);
            parametros.Add("@ParamCodPeriodo", periodo);
            parametros.Add("@ParamListaVisao", listaVisao);
            parametros.Add("@ParamListaSegmento", listaistaSegmento);
            parametros.Add("@ParamListaEncarteiramento", listaEncarteiramento);
            parametros.Add("@ParamListaSuperintendencia", listaSuperintendencia);
            parametros.Add("@ParamListaRegiao", listaRegiao);
            parametros.Add("@ParamListaEstado", listaEstado);
            parametros.Add("@ParamCodAtributoNPS", codTabulacaoItem);

            return parametros;
        }

    }
}
