﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.NPSSegmentoModel
{
    public class ComboAtributosModel
    {
        public int IdItem { get; set; }
        public string DescItem { get; set; }

    }
}
