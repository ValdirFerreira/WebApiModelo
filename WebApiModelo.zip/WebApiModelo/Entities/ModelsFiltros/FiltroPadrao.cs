﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.ModelsFiltros
{
    public class FiltroPadrao
    {
        public int ParamTipoPeriodo { get; set; }
        public int ParamPeriodo { get; set; }
        public List<string> ParamVisaoMPE { get; set; }
        public List<string> ParamSegmento { get; set; }
        public List<string> ParamEncarteiramento { get; set; }
        public List<string> ParamSuperintendencia { get; set; }
        public List<string> ParamRegiao { get; set; }
        public List<string> ParamEstado { get; set; }
        public int ParamCodTabulacaoItem { get; set; }
    }
}
